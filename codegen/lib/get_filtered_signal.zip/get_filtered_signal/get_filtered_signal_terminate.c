/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * get_filtered_signal_terminate.c
 *
 * Code generation for function 'get_filtered_signal_terminate'
 *
 */

/* Include files */
#include "get_filtered_signal_terminate.h"
#include "get_filtered_signal.h"

/* Function Definitions */
void get_filtered_signal_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (get_filtered_signal_terminate.c) */
