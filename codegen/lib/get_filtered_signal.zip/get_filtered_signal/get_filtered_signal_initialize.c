/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * get_filtered_signal_initialize.c
 *
 * Code generation for function 'get_filtered_signal_initialize'
 *
 */

/* Include files */
#include "get_filtered_signal_initialize.h"
#include "get_filtered_signal.h"

/* Function Definitions */
void get_filtered_signal_initialize(void)
{
}

/* End of code generation (get_filtered_signal_initialize.c) */
