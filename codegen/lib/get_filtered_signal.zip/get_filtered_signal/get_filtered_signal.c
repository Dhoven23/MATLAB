/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * get_filtered_signal.c
 *
 * Code generation for function 'get_filtered_signal'
 *
 */

/* Include files */
#include "get_filtered_signal.h"
#include "fft.h"
#include "ifft.h"
#include <string.h>

/* Function Definitions */

/*
 * function ffilt =  get_filtered_signal(y,Sampling_frequency)
 */
void get_filtered_signal(const double y[23085504], double Sampling_frequency,
  creal_T ffilt[1486272])
{
  static double x[1486272];
  int j;
  int i;
  static creal_T fhat[1486272];
  double fhat_re;
  (void)Sampling_frequency;

  /* 'get_filtered_signal:2' Fs = Sampling_frequency; */
  /* 'get_filtered_signal:3' Filter_limit = 1; */
  /* 'get_filtered_signal:6' PSD = zeros(1,1000); */
  /* 'get_filtered_signal:7' x = zeros(1,1486272); */
  memset(&x[0], 0, 1486272U * sizeof(double));

  /* 'get_filtered_signal:10' Fn = Fs/2; */
  /* 'get_filtered_signal:11' dt = 1/Fs; */
  /* 'get_filtered_signal:13' i = 1; */
  /* 'get_filtered_signal:14' j = 1; */
  j = 0;

  /* 'get_filtered_signal:16' for i = 1:length(y) */
  for (i = 0; i < 11542752; i++) {
    /* 'get_filtered_signal:17' if y(i) ~= 0 */
    if (y[i] != 0.0) {
      /* 'get_filtered_signal:19' x(j) = y(i); */
      x[j] = y[i];

      /* 'get_filtered_signal:20' j = j + 1; */
      j++;
    }
  }

  /* 'get_filtered_signal:25' n = length(x); */
  /* 'get_filtered_signal:26' fhat = fft(x,n); */
  fft(x, fhat);

  /* 'get_filtered_signal:28' PSD = fhat.*conj(fhat)/n; */
  /* 'get_filtered_signal:29' indices = PSD>Filter_limit; */
  /* 'get_filtered_signal:30' PSDclean = PSD.*indices; */
  /* 'get_filtered_signal:31' fhat = indices.*fhat; */
  for (j = 0; j < 1486272; j++) {
    fhat_re = fhat[j].re * fhat[j].re - fhat[j].im * -fhat[j].im;
    if (fhat[j].re * -fhat[j].im + fhat[j].im * fhat[j].re == 0.0) {
      fhat_re /= 1.486272E+6;
    } else if (fhat_re == 0.0) {
      fhat_re = 0.0;
    } else {
      fhat_re /= 1.486272E+6;
    }

    fhat[j].re *= (double)(fhat_re > 1.0);
    fhat[j].im *= (double)(fhat_re > 1.0);
  }

  /* 'get_filtered_signal:33' ffilt = ifft(fhat); */
  ifft(fhat, ffilt);
}

/* End of code generation (get_filtered_signal.c) */
